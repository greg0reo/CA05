#include "Card.h"

using namespace std;

Card::Card(int j, string k){
	this->n = j;
	this->f = k;
}